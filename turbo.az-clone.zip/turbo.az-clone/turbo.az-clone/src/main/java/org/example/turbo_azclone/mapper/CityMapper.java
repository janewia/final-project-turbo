package org.example.turbo_azclone.mapper;
import org.example.turbo_azclone.dao.entity.CityEntity;
import org.example.turbo_azclone.model.CityDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public abstract class CityMapper {
    public static CityMapper mapper = Mappers.getMapper(CityMapper.class);

    public abstract CityDto mapEntityToDto(CityEntity cityEntity);

    public abstract CityEntity mapDtoToEntity(CityDto cityDto);
    public abstract CityEntity mapDtoToEntity(CityDto cityDto,Integer cityId);

    public abstract List<CityDto> mapEntityToDtos(List<CityEntity> cityEntities);
}
