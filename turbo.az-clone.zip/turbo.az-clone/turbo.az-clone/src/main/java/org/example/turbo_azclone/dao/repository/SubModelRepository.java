package org.example.turbo_azclone.dao.repository;

import org.example.turbo_azclone.dao.entity.ModelEntity;
import org.example.turbo_azclone.dao.entity.SubModelEntity;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface SubModelRepository extends JpaRepository<SubModelEntity, Integer>, JpaSpecificationExecutor<SubModelEntity> {

}
