package org.example.turbo_azclone.model;
import org.example.turbo_azclone.dao.entity.BrandEntity;
import org.example.turbo_azclone.dao.entity.SubModelEntity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ModelDto {
    private Integer id;
    private String name;
    private List<SubModelDto> subModel;
}
