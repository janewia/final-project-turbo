package org.example.turbo_azclone.model;

import org.example.turbo_azclone.dao.entity.ModelEntity;
import org.example.turbo_azclone.dao.entity.ProductEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class SubModelDto {
    private String name;
}
