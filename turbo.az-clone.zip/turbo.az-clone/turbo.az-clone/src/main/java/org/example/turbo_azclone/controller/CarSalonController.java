package org.example.turbo_azclone.controller;

import org.example.turbo_azclone.dao.entity.CarSalonEntity;
import org.example.turbo_azclone.dao.entity.enums.ECarSalon;
import org.example.turbo_azclone.model.BrandDto;
import org.example.turbo_azclone.model.CarSalonDto;
import org.example.turbo_azclone.model.CarSalonLiteDto;
import org.example.turbo_azclone.service.CarSalonService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/carSalons")
public class CarSalonController {
    private final CarSalonService carSalonService;

    public CarSalonController(CarSalonService carSalonService) {
        this.carSalonService = carSalonService;
    }
    @GetMapping("/public/bySalonType/{salonType}")
    public List<CarSalonLiteDto> getAllCarSalon(@PathVariable ECarSalon salonType){
        return carSalonService.getAllCarSalon(salonType);
    }
    @GetMapping("/public/byId/{carSalonId}")
    public CarSalonDto getCarSalon(@PathVariable Integer carSalonId){
        return carSalonService.getCarSalon(carSalonId);
    }
    @PostMapping("/admin")
    @PreAuthorize("hasAnyRole('ADMIN')")
    public void saveCarSalon(@RequestBody CarSalonLiteDto carSalonLiteDto){
        carSalonService.saveCarSalon(carSalonLiteDto);
    }
    @PutMapping("/admin/{carSalonId}")
    @PreAuthorize("hasAnyRole('ADMIN')")
    public void updateCarSalon(@RequestBody CarSalonDto carSalonDto, @PathVariable Integer carSalonId){
        carSalonService.editCarSalon(carSalonDto,carSalonId);
    }
    @DeleteMapping("/admin/{carSalonId}")
    @PreAuthorize("hasAnyRole('ADMIN')")
    public void deleteCarSalon(@PathVariable Integer carSalonId){
        carSalonService.deleteCarSalon(carSalonId);
    }
}
