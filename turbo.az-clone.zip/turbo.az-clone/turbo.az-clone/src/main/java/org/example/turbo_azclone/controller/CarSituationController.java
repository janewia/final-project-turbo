package org.example.turbo_azclone.controller;


import org.example.turbo_azclone.model.CarSituationDto;
import org.example.turbo_azclone.service.CarSituationService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/carSituations")
public class CarSituationController {
    private final CarSituationService carSituationService;

    public CarSituationController(CarSituationService carSituationService) {
        this.carSituationService = carSituationService;
    }

    @GetMapping
    public List<CarSituationDto> getAllCarSituation() {
        return carSituationService.getAllCarSituation();
    }
}
