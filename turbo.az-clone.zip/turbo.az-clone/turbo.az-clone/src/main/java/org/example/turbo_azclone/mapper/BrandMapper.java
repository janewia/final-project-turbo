package org.example.turbo_azclone.mapper;
import org.example.turbo_azclone.dao.entity.BrandEntity;
import org.example.turbo_azclone.model.BrandDto;
import org.example.turbo_azclone.model.BrandLiteDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public abstract class BrandMapper {
    public static BrandMapper mapper = Mappers.getMapper(BrandMapper.class);

    public abstract BrandDto mapEntityToDto(BrandEntity brandEntity);
    public abstract BrandEntity mapDtoToEntity(BrandDto brandDto);
    public abstract BrandEntity mapDtoToEntity(BrandDto brandDto, Integer brandId);
    public abstract List<BrandDto> mapEntityToDtos(List<BrandEntity> brandEntities);
    public abstract BrandLiteDto mapEntityToDto2(BrandEntity brandEntity);
    public abstract BrandEntity mapDtoToEtity2(BrandLiteDto brandLiteDto);
    public abstract List<BrandLiteDto> mapEntityToDtos2(List<BrandEntity> brandEntities);


}
