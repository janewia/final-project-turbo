package org.example.turbo_azclone.dao.entity.enums;

public enum EProduct {
    VIP,
    SIMPLE
}
