package org.example.turbo_azclone.dao.entity.enums;

public enum PriceType {
    AZN,
    USD,
    EUR
}
