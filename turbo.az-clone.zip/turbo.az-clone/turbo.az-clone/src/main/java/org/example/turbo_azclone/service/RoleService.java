package org.example.turbo_azclone.service;

import org.example.turbo_azclone.dao.repository.RoleRepository;
import org.example.turbo_azclone.mapper.RoleMapper;
import org.example.turbo_azclone.model.auth.RoleDto;
import org.springframework.stereotype.Service;

@Service
public class RoleService {
    private final RoleRepository roleRepository;

    public RoleService(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    public void saveRole(RoleDto roleDto) {
        roleRepository.save(RoleMapper.mapper.mapDtoToEntity(roleDto));
    }

}

