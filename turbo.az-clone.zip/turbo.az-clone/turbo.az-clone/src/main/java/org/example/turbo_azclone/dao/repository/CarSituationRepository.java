package org.example.turbo_azclone.dao.repository;
import org.example.turbo_azclone.dao.entity.CarSituationEntity;
import org.example.turbo_azclone.model.CarSituationDto;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;


public interface CarSituationRepository extends JpaRepository<CarSituationEntity, Integer>, JpaSpecificationExecutor<CarSituationEntity> {

}