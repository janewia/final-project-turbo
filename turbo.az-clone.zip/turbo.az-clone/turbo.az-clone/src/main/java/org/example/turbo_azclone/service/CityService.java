package org.example.turbo_azclone.service;


import org.example.turbo_azclone.dao.entity.CityEntity;
import org.example.turbo_azclone.dao.repository.CityRepository;
import org.example.turbo_azclone.mapper.CityMapper;
import org.example.turbo_azclone.model.CityDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class CityService {
    private final CityRepository cityRepository;

    public CityService(CityRepository cityRepository) {
        this.cityRepository = cityRepository;

    }

    public List<CityDto> getAllCity() {
        log.info("ActionLog.getAllCity.start");
        List<CityDto> cityDtos =
                CityMapper.mapper.mapEntityToDtos(cityRepository.findAll());
        log.info("ActionLog.getAllCity.end");
        return cityDtos;
    }

    public CityDto getCity(Integer cityId) {
        log.info("ActionLog.getCity.start");
        CityEntity cityEntity =
                cityRepository.findById(cityId).orElseThrow(() ->
                        new RuntimeException("Not found")
                );
        log.info("ActionLog.getCity.end");
        return CityMapper.mapper.mapEntityToDto(cityEntity);

    }

    public void saveCity(CityDto cityDto) {
        log.info("ActionLog.saveCity.start");
        cityRepository.save(CityMapper.mapper.mapDtoToEntity(cityDto));
        log.info("ActionLog.saveCity.end");
    }

    public void editCity(CityDto cityDto, Integer cityId) {
        log.info("ActionLog.editCity.start");
        CityEntity existingCity = cityRepository.findById(cityId).orElse(null);
        if (existingCity != null) {
            existingCity.setName(cityDto.getName());
            cityRepository.saveAndFlush(existingCity);
        }

        log.info("ActionLog.editCity.end");
    }

    public void deleteCity(Integer cityId) {
        log.info("ActionLog.deleteCity.start");
        cityRepository.deleteById(cityId);
        log.info("ActionLog.deleteCity.end");
    }


}
