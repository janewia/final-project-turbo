package org.example.turbo_azclone.dao.repository;

import org.example.turbo_azclone.dao.entity.BrandEntity;
import org.example.turbo_azclone.model.BrandDto;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;

public interface BrandRepository extends JpaRepository<BrandEntity, Integer>, JpaSpecificationExecutor<BrandEntity> {
    BrandEntity findByName(String name);
}
