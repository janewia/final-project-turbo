package org.example.turbo_azclone.dao.entity.enums;

public enum ProductActiveStatus {
    PENDING,
    REJECT,
    ACTIVE,
    EXPIRED
}