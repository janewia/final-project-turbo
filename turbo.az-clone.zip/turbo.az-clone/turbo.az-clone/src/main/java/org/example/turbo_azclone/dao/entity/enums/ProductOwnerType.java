package org.example.turbo_azclone.dao.entity.enums;

public enum ProductOwnerType {
    USER,
    CAR_SALON
}