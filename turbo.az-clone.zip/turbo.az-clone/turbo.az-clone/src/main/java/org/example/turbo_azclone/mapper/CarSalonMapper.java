package org.example.turbo_azclone.mapper;

import org.example.turbo_azclone.dao.entity.CarSalonEntity;
import org.example.turbo_azclone.model.CarSalonDto;
import org.example.turbo_azclone.model.CarSalonLiteDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public abstract class CarSalonMapper {
    public static CarSalonMapper mapper = Mappers.getMapper(CarSalonMapper.class);

    public abstract CarSalonDto mapEntityToDto(CarSalonEntity carSalonEntity);

    public abstract CarSalonEntity mapDtoToEntity(CarSalonDto carSalonDto);

    public abstract CarSalonEntity mapDtoToEntity(CarSalonDto carSalonDto, Integer carSalonId);

    public abstract List<CarSalonDto> mapEntityToDtos(List<CarSalonEntity> carSalonEntities);
    public abstract CarSalonLiteDto mapEntityToDto2(CarSalonEntity carSalonEntity);
    public abstract List<CarSalonLiteDto> mapEntityToDtos2(List<CarSalonEntity> carSalonEntities);
    public abstract CarSalonEntity mapLiteDtoToEntity(CarSalonLiteDto carSalonLiteDto);
}
