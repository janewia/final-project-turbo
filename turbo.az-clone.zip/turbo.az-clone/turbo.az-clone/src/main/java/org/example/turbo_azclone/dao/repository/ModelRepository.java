package org.example.turbo_azclone.dao.repository;
import org.example.turbo_azclone.dao.entity.CityEntity;
import org.example.turbo_azclone.dao.entity.ModelEntity;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface ModelRepository extends JpaRepository<ModelEntity, Integer>, JpaSpecificationExecutor<ModelEntity> {
}