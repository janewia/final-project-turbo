package org.example.turbo_azclone.dao.entity.enums;

public enum ECarSalon {
    OFFICIAL,
    SIMPLE
}
