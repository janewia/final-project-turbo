package org.example.turbo_azclone.mapper;

import org.example.turbo_azclone.dao.entity.CarSituationEntity;
import org.example.turbo_azclone.model.CarSituationDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public abstract class CarSituationMapper {
    public static CarSituationMapper mapper = Mappers.getMapper(CarSituationMapper.class);

    public abstract CarSituationDto mapEntityToDto(CarSituationEntity carSituationEntity);

    public abstract CarSituationEntity mapDtoToEntity(CarSituationDto carSituationDto);
    public abstract CarSituationEntity mapDtoToEntity(CarSituationDto carSituationDto,Integer carSituationId);

    public abstract List<CarSituationDto> mapEntityToDtos(List<CarSituationEntity> carSituationEntities);
}