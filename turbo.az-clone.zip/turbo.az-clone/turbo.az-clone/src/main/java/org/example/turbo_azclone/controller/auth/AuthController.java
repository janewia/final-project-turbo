package org.example.turbo_azclone.controller.auth;

import org.example.turbo_azclone.model.UserDto;
import org.example.turbo_azclone.model.auth.AuthRequestDto;
import org.example.turbo_azclone.model.auth.AuthenticationDto;
import org.example.turbo_azclone.model.auth.UserRegisterRequestDto;
import org.example.turbo_azclone.service.auth.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public void register(
            @RequestBody UserRegisterRequestDto requestDto
    ) {
        authService.register(requestDto);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthenticationDto> login(
            @RequestBody AuthRequestDto authRequestDto
    ) {
        return ResponseEntity.ok(authService.authenticate(authRequestDto));
    }
    @DeleteMapping("/user/{userId}")
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public void deleteUser(@PathVariable Integer userId){
        authService.deleteUser(userId);
    }
}
