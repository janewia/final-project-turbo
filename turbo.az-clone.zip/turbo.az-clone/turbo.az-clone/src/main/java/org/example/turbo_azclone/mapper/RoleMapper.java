package org.example.turbo_azclone.mapper;
import org.example.turbo_azclone.dao.entity.RoleEntity;
import org.example.turbo_azclone.model.auth.RoleDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public abstract class RoleMapper {
    public static RoleMapper mapper = Mappers.getMapper(RoleMapper.class);
    public abstract RoleEntity mapDtoToEntity(RoleDto roleDto);
    public abstract RoleDto mapEntityToDto(RoleEntity roleEntity);


}

