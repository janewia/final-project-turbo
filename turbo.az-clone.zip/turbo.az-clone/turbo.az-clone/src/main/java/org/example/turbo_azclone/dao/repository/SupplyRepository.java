package org.example.turbo_azclone.dao.repository;

import org.example.turbo_azclone.dao.entity.SupplyEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;


public interface SupplyRepository extends JpaRepository<SupplyEntity, Integer>, JpaSpecificationExecutor<SupplyEntity> {
}