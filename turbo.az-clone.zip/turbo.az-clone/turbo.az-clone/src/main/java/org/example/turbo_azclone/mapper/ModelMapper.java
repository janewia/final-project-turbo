package org.example.turbo_azclone.mapper;

import org.example.turbo_azclone.dao.entity.ModelEntity;
import org.example.turbo_azclone.model.ModelDto;
import org.example.turbo_azclone.model.ModelLiteDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public abstract class ModelMapper {
    public static ModelMapper mapper = Mappers.getMapper(ModelMapper.class);
    public abstract ModelDto mapEntityToDto(ModelEntity modelEntity);
    @Mapping(target="name",source = "name")
    @Mapping(target="brand.id",source = "brandId")
    public abstract ModelEntity mapDtoToEntity(ModelLiteDto modelDto);

    public abstract List<ModelDto> mapEntityToDtos(List<ModelEntity> modelEntities);

}
