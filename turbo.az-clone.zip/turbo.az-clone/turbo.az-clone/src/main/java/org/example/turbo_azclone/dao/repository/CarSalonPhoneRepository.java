package org.example.turbo_azclone.dao.repository;
import org.example.turbo_azclone.dao.entity.CarSalonPhoneEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarSalonPhoneRepository extends JpaRepository<CarSalonPhoneEntity, Integer>{
}
