package org.example.turbo_azclone.model;
import org.example.turbo_azclone.dao.entity.ProductEntity;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class CityDto {
    @Pattern(regexp = "^[a-zA-Z]+$", message = "Should contain only alphabetic characters.")
    private String name;
}
