package org.example.turbo_azclone.model;

import org.example.turbo_azclone.dao.entity.RoleEntity;
import org.example.turbo_azclone.model.auth.RoleDto;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class UserDto {
    private String phoneNumber;
    private Double balance;
    private String email;
}
